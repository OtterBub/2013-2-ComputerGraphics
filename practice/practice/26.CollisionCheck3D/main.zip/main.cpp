
#include <gl\glut.h>
#include <gl\GL.h>
#include <gl\GLU.h>

#include <cstdlib>
#include <cstdio>
#include <ctime>

#include <stdio.h>

#define HEIGHT 600
#define WIDTH 800

#define GROUND_SIZE 300.0f

GLvoid drawScene( GLvoid );
GLvoid reshape( int w, int h );
GLvoid mouse(int button, int state, int x, int y);
GLvoid timerFunc(int val);
GLvoid mouseMove(int x, int y);
GLvoid keyBoardFunc(unsigned char key, int x, int y);
GLvoid specialKeyBoardFunc(int key, int x, int y);
GLvoid MenuFuntion(int value);
void drawStrokeText(char *string, int x, int y, int z);

// --------------------------------------------------------------------------


typedef struct _POINT {
	float x, y, z;
} POINT;

typedef struct _COLLISIONBOX {
	POINT Max;
	POINT Min;
} COLLISIONBOX;

typedef struct _OBJECT {
	int width;
	int height;
	POINT point;
	COLLISIONBOX box;
} OBJECT;

bool CollisionCheck(COLLISIONBOX A, COLLISIONBOX B)
{
	if( (A.Max.x > B.Min.x) && (A.Min.x < B.Max.x) &&
		(A.Max.y > B.Min.y) && (A.Min.y < B.Max.y) &&
		(A.Max.z > B.Min.z) && (A.Min.z < B.Max.z))
		return true;
	return false;
}

// --------------------------------------------------------------------------


void main(int argc, char *argv[])
{
	srand((unsigned)time(NULL));
	glutInitDisplayMode( GLUT_DOUBLE | GLUT_RGBA | GLUT_DEPTH );
	glutInitWindowPosition( 100, 100 );
	glutInitWindowSize( WIDTH, HEIGHT );
	glutCreateWindow( "21.Curve" );
	glutDisplayFunc( drawScene );
	glutReshapeFunc( reshape );
	glutMouseFunc( mouse );
	glutMotionFunc( mouseMove );
	glutKeyboardFunc( keyBoardFunc );
	glutSpecialFunc( specialKeyBoardFunc );

	glutTimerFunc( 600, timerFunc, 1 );

	glutMainLoop();
}

int g_Shage = 0; // Wire
float g_x;
float g_y;
float g_z;

double g_eye_x = 0, g_eye_y = 300, g_eye_z = 800;
double g_center_x, g_center_y, g_center_z = -1;
double g_up_x, g_up_y, g_up_z;
double g_w, g_h;

double g_r = 0.3, g_g = 0.3, g_b = 0.5;

bool g_init = false;

#define OBSTACLE_NUM 100

OBJECT controllUnit;
OBJECT Obstacle[OBSTACLE_NUM];

// --------------------------------------------------------------------------


void init()
{
	if(g_init)
		return;
	else
		g_init = true;

	controllUnit.height = 10;
	controllUnit.width = 10;
	controllUnit.point.x = 0;
	controllUnit.point.y = 0;
	controllUnit.point.z = 0;

	controllUnit.box.Max = controllUnit.point;
	controllUnit.box.Min = controllUnit.point;

	controllUnit.box.Max.x += controllUnit.width;
	controllUnit.box.Max.y += controllUnit.width + 10;
	controllUnit.box.Max.z += controllUnit.width;

	controllUnit.box.Min.x += -controllUnit.width;
	controllUnit.box.Min.y += 1;
	controllUnit.box.Min.z += -controllUnit.width;

	for(int i = 0; i < OBSTACLE_NUM; i++){
		Obstacle[i].point.x = rand() % 600 - 300;
		Obstacle[i].point.y = 1;
		Obstacle[i].point.z = rand() % 600 - 300;
		Obstacle[i].width = 20;
		Obstacle[i].height = 20;

		Obstacle[i].box.Max = Obstacle[i].point;
		Obstacle[i].box.Min = Obstacle[i].point;

		Obstacle[i].box.Max.x += 10;
		Obstacle[i].box.Max.y += 20;
		Obstacle[i].box.Max.z += 10;

		Obstacle[i].box.Min.x -= 10;
		Obstacle[i].box.Min.y -= 1;
		Obstacle[i].box.Min.z -= 10;
	}

	glEnable(GL_DEPTH_TEST);

}

GLvoid drawScene ( GLvoid )
{
	init();

	//glClearColor( 0.0f, 0.3f, 0.3f, 1.0f ); (Blue Black)
	glClearColor( g_r, g_g, g_b, 1.0f );
	glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );

	// Camera Control
	gluLookAt(g_eye_x, g_eye_y, g_eye_z,
		g_center_x, g_center_y, g_center_z,
		0.0, 1.0, 0.0);

	// Global View;
	//glTranslatef( g_eye_x, g_eye_y, g_eye_z );
	glTranslatef( 0, 0, 0 );
	glRotatef(g_x, 1.0, 0.0, 0.0);
	glRotatef(g_y, 0.0, 1.0, 0.0);
	glRotatef(g_z, 0.0, 0.0, 1.0);

	// Draw Ground
	glColor3f(0.0, 0.7, 0.7);
	glBegin(GL_POLYGON);
	glVertex3f(-GROUND_SIZE, 0.0, -GROUND_SIZE);
	glVertex3f(GROUND_SIZE, 0.0, -GROUND_SIZE);
	glVertex3f(GROUND_SIZE, 0.0, GROUND_SIZE);
	glVertex3f(-GROUND_SIZE, 0.0, GROUND_SIZE);
	glEnd();

	// Draw 3DWorld Object
	glPushMatrix();
	{
		POINT currentPos = controllUnit.point;
		glColor3f(1, 0, 0);
		glTranslatef(currentPos.x, currentPos.y + 11, currentPos.z);
		glutWireSphere(controllUnit.width, 10, 10);

	}
	glPopMatrix();

	glPushMatrix();
	{
		glColor3f(1, 0, 0);
		glBegin(GL_LINE_LOOP);
		glVertex3f(controllUnit.box.Min.x, controllUnit.box.Min.y, controllUnit.box.Min.z);
		glVertex3f(controllUnit.box.Max.x, controllUnit.box.Min.y, controllUnit.box.Min.z);
		glVertex3f(controllUnit.box.Max.x, controllUnit.box.Max.y, controllUnit.box.Min.z);
		glVertex3f(controllUnit.box.Min.x, controllUnit.box.Max.y, controllUnit.box.Min.z);
		glEnd();	

		glBegin(GL_LINE_LOOP);
		glVertex3f(controllUnit.box.Min.x, controllUnit.box.Min.y, controllUnit.box.Min.z);
		glVertex3f(controllUnit.box.Min.x, controllUnit.box.Min.y, controllUnit.box.Max.z);
		glVertex3f(controllUnit.box.Min.x, controllUnit.box.Max.y, controllUnit.box.Max.z);
		glVertex3f(controllUnit.box.Min.x, controllUnit.box.Max.y, controllUnit.box.Min.z);
		glEnd();	

		glBegin(GL_LINE_LOOP);
		glVertex3f(controllUnit.box.Min.x, controllUnit.box.Min.y, controllUnit.box.Min.z);
		glVertex3f(controllUnit.box.Min.x, controllUnit.box.Min.y, controllUnit.box.Max.z);
		glVertex3f(controllUnit.box.Min.x, controllUnit.box.Max.y, controllUnit.box.Max.z);
		glVertex3f(controllUnit.box.Min.x, controllUnit.box.Max.y, controllUnit.box.Min.z);
		glEnd();	

		glBegin(GL_LINE_LOOP);
		glVertex3f(controllUnit.box.Min.x, controllUnit.box.Min.y, controllUnit.box.Min.z);
		glVertex3f(controllUnit.box.Min.x, controllUnit.box.Min.y, controllUnit.box.Max.z);
		glVertex3f(controllUnit.box.Max.x, controllUnit.box.Min.y, controllUnit.box.Max.z);
		glVertex3f(controllUnit.box.Max.x, controllUnit.box.Min.y, controllUnit.box.Min.z);
		glEnd();	

		glBegin(GL_LINE_LOOP);
		glVertex3f(controllUnit.box.Max.x, controllUnit.box.Max.y, controllUnit.box.Max.z);
		glVertex3f(controllUnit.box.Max.x, controllUnit.box.Min.y, controllUnit.box.Max.z);
		glVertex3f(controllUnit.box.Max.x, controllUnit.box.Min.y, controllUnit.box.Min.z);
		glVertex3f(controllUnit.box.Max.x, controllUnit.box.Max.y, controllUnit.box.Min.z);
		glEnd();	

		glBegin(GL_LINE_LOOP);
		glVertex3f(controllUnit.box.Max.x, controllUnit.box.Max.y, controllUnit.box.Max.z);
		glVertex3f(controllUnit.box.Min.x, controllUnit.box.Max.y, controllUnit.box.Max.z);
		glVertex3f(controllUnit.box.Min.x, controllUnit.box.Min.y, controllUnit.box.Max.z);
		glVertex3f(controllUnit.box.Max.x, controllUnit.box.Min.y, controllUnit.box.Max.z);
		glEnd();
	}
	glPopMatrix();

	for(int i = 0 ; i < OBSTACLE_NUM; i++){
		glPushMatrix();
		{
			POINT currentPos = Obstacle[i].point;
			glColor3f(1, 1, 1);
			glTranslatef(currentPos.x, currentPos.y + 11, currentPos.z);
			glutWireCube(Obstacle[i].width);
		}
		glPopMatrix();
	}	

	glLoadIdentity();
	glutSwapBuffers();
}

#define CAMERA_EYE_SPEED 10

GLvoid keyBoardFunc(unsigned char key, int x, int y)
{
	static float CHAR_SPD = 3;

	OBJECT tempobj = controllUnit;

	switch(key)
	{
	case '1':
		break;
	case 'a':
		//g_eye_x -= CAMERA_EYE_SPEED;
		g_y -= 1;
		break;
	case 'd':
		//g_eye_x += CAMERA_EYE_SPEED;
		g_y += 1;
		break;
	case 'w':
		g_eye_z -= CAMERA_EYE_SPEED;
		//g_center_z -= CAMERA_EYE_SPEED;
		break;
	case 's':
		g_eye_z += CAMERA_EYE_SPEED;
		//g_center_z += CAMERA_EYE_SPEED;
		break;
	case 'r':
		g_eye_y += CAMERA_EYE_SPEED;
		break;
	case 'f':
		g_eye_y -= CAMERA_EYE_SPEED;
		break;
	case 'q':
		g_eye_x -= CAMERA_EYE_SPEED;
		g_center_x -= CAMERA_EYE_SPEED;
		break;
	case 'e':
		g_eye_x += CAMERA_EYE_SPEED;
		g_center_x += CAMERA_EYE_SPEED;
		break;
	case 'x':
		g_x--;
		break;
	case 'X':
		g_x++;
		break;
	case 'y':
		g_y--;
		break;
	case 'Y':
		g_y++;
		break;
	case 'z':
		g_z--;
		break;
	case 'Z':
		g_z++;
		break;
	case 't':
		g_r-=0.05;
		break;
	case 'T':
		g_r+=0.05;
		break;
	case 'g':
		g_g-=0.05;
		break;
	case 'G':
		g_g+=0.05;
		break;
	case 'b':
		g_b-=0.05;
		break;
	case 'B':
		g_b+=0.05;
		break;
	case ' ':

		break;

	case 'i':
		tempobj.point.z -= CHAR_SPD;
		break;
	case 'k':
		tempobj.point.z += CHAR_SPD;
		break;
	case 'j':
		tempobj.point.x -= CHAR_SPD;
		break;
	case 'l':
		tempobj.point.x += CHAR_SPD;
		break;
	default:
		break;
	}

	// controllUnit collisionbox Update
	tempobj.box.Max = tempobj.point;
	tempobj.box.Min = tempobj.point;

	tempobj.box.Max.x += tempobj.width;
	tempobj.box.Max.y += tempobj.width + 10;
	tempobj.box.Max.z += tempobj.width;

	tempobj.box.Min.x += -tempobj.width;
	tempobj.box.Min.y += 1;
	tempobj.box.Min.z += -tempobj.width;

	bool collision = false;

	for(int i = 0; i < OBSTACLE_NUM; i++){
		if(CollisionCheck(tempobj.box, Obstacle[i].box))
			collision = true;
	}

	if(collision)
		return;
	else
		controllUnit = tempobj;
}

GLvoid reshape ( int w, int h )
{
	g_w = w;
	g_h = h;
	glViewport(0, 0, w, h);

	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();

	//glOrtho(0, w, 0, h, -h, h);
	gluPerspective(60, w/h, 1.0, 2000.0f);
	/*gluLookAt(0.0, 0.0, 500.0,
	0.0, 0.0, 0.0,
	0.0, 1.0, 0.0);*/

	glMatrixMode(GL_MODELVIEW);
}

// --------------------------------------------------------------------------

double pre_x, pre_y;

GLvoid mouse(int button, int state, int x, int y)
{
	int r_y = HEIGHT - y;
	//printf("mouse x : %d, y : %d\n", x, y);

	pre_x = x;
	pre_y = y;

	if(state == GLUT_DOWN) {
		switch (button)	{
		case GLUT_LEFT_BUTTON:
			break;

		case GLUT_RIGHT_BUTTON:
			break;		

		default:
			break;
		}
	}
}

GLvoid mouseMove(int x, int y)
{
	int r_y = HEIGHT - y;

	//printf("%f, %f \n", x - pre_x, y - pre_y);

	g_y += (float)(x - pre_x) / 10.0f;
	g_x += (float)(y - pre_y) / 10.0f;

	pre_x = x;
	pre_y = y;
}

GLvoid timerFunc(int val)
{
	glutPostRedisplay();
	glutTimerFunc( 16, timerFunc, 1 );
}

GLvoid specialKeyBoardFunc(int key, int x, int y)
{
	// left : 100 / up : 101 / right : 102 / down : 103
	// page up : 104 / page down : 105
	switch(key)
	{
	case 100:
		g_center_x -= CAMERA_EYE_SPEED;
		break;
	case 102:
		g_center_x += CAMERA_EYE_SPEED;
		break;
	case 101:
		g_center_z -= CAMERA_EYE_SPEED;
		break;
	case 103:
		g_center_z += CAMERA_EYE_SPEED;
		break;
	case 104:
		g_center_y += CAMERA_EYE_SPEED;
		break;
	case 105:
		g_center_y -= CAMERA_EYE_SPEED;
		break;
	}
	printf("%d\n", key);
}

GLvoid MenuFuntion(int value)
{
	switch(value){
	case 1:
		glEnable(GL_DEPTH_TEST);
		break;
	case 2:
		glDisable(GL_DEPTH_TEST);
		break;

	case 11:
		glEnable(GL_CULL_FACE);
		break;
	case 22:
		glDisable(GL_CULL_FACE);
		break;

	case 111:
		glShadeModel(GL_FLAT);
		break;
	case 222:
		glShadeModel(GL_SMOOTH);
		break;

	default:
		break;
	}
}

void drawStrokeText(char *string, int x, int y, int z) {
	char *c;
	glPushMatrix();
	{
		glTranslatef(x, y + 8, z);
		glColor3f(1.0, 1.0, 1.0);
		glScalef(0.09f, 0.08f, z);
		for(c = string; *c != '\0'; c++)
			glutStrokeCharacter(GLUT_STROKE_ROMAN, *c);
	}
	glPopMatrix();
}